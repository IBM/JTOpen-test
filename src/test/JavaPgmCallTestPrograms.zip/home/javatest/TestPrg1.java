import java.net.*;
import java.io.*;
import com.ibm.as400.access.*;

class TestPrg1
{
    public static void main(String[] argv)
    {
		System.out.println("The end of test program1!");
        System.exit(0);
            
    }
 }
