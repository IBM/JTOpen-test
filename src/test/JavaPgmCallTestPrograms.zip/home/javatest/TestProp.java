class TestProp
{
    public static void main(String[] args)
    {
        String propStr = System.getProperty("TEST");
        System.out.println("The property TEST = "+propStr);
    }
}
