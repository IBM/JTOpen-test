import java.io.*;

class TestPort1
{
  public static void main(String[] argv)
  {
    PrintWriter writer = null;
    try
    {
      String firstString;			
      String errorString;
      writer = new PrintWriter(new FileWriter("/tmp/TestPort1.txt"));
      writer.println("TestPort1.main(): Started");

      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

      firstString = in.readLine();        	                 	
      System.out.println(firstString);
      writer.println("Received firstString: |" + firstString + "|");

      errorString = in.readLine();
      System.err.println(errorString); 
      writer.println("Received errorString: |" + errorString + "|");
    }
    catch(Exception e)
    {
      System.out.println("An exception occured: "+e);
      try { writer.println("An exception occured: "+e); } catch (Throwable t) {}
    }
    finally
    {
      if (writer != null) try { writer.close(); } catch (Throwable t) {}
    }
    System.exit(0);            
  }
}
