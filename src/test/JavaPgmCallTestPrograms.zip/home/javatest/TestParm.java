import java.net.*;
import java.io.*;
import com.ibm.as400.access.*;

class TestParm
{
    public static void main(String[] argv)
    {
        if(argv.length==0)
        	System.out.println("No parameter input!");
        else if(argv.length==1)
            System.out.println("One parameter input: "+argv[0]);
        else if(argv.length==2)
            System.out.println("Two parameters input: "+argv[0]+" & "+argv[1]);
        else 
            System.out.println("Too many parameters!");
        System.exit(0);
            
    }
 }
