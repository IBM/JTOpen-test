import java.io.*;

class TestIOE
{
    public static void main(String[] argv)
    {
        try
        {
			String firstString;
			String secondString;

        	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

			System.out.println("I am from stdout,please input a string:");
        	firstString = in.readLine();
        	System.err.println("I am from stderr,please input another string:");
        	secondString = in.readLine();
        	System.out.println("I am from stdout,you have input "+firstString+" and "+secondString);
        }
        catch(Exception e)
        {
        	System.out.println("An exception occured: "+e);
        }
        System.exit(0);
            
    }
 }
